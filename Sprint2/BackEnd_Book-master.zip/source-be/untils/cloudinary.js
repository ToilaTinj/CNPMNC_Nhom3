require('dotenv').config();

const cloudinary = require('cloudinary');

cloudinary.config({
    cloud_name: "leanhduc",
    api_key: "813638665716957",
    api_secret: 'ijhCfoIcYo96pEBrCW7ov5R4l0E'
})

exports.uploads = (file, folder) => {
    return new Promise(resolve => {
        cloudinary.uploader.upload(file, (result) => {
            resolve({
                url: result.secure_url,
                id: result.public_id
            })
        }, {
            resource_type: "auto",
            folder: folder
        })
    })
}
