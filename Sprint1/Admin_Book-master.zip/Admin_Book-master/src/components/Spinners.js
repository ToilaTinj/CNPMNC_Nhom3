import React from 'react';

function Spinners(props) {
    return (
        <div class="spinner-border" role="status" style={{ height: '20px', width: '20px' }}> </div>
    );
}

export default Spinners;