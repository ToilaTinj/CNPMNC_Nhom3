export function createMarkup(theExactHtmlWithTag) {
    return { __html: theExactHtmlWithTag };
}