export const toastConfig = {
    position: 'top-center',
    autoClose: 3000,
    closeButton: true,
    className: "toast-custom"
}